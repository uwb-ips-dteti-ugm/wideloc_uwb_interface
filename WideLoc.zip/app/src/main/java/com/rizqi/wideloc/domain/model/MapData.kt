package com.rizqi.wideloc.domain.model

data class MapData(
    val id: Int = 0,
    val name: String = "",
    val imageUri: String = "",
)
