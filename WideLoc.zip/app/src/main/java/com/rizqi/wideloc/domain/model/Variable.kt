package com.rizqi.wideloc.domain.model

data class Variable(
    val id: String,
    var value: Double,
)
