package com.rizqi.wideloc.domain.model

data class CalibrationData(
    val data: String,
)
