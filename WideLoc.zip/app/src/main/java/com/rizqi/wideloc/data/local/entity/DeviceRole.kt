package com.rizqi.wideloc.data.local.entity

enum class DeviceRole {
    Server,
    Anchor,
    Client
}