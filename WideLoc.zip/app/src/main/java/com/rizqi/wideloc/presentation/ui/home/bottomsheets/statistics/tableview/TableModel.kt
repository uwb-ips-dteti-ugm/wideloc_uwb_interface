package com.rizqi.wideloc.presentation.ui.home.bottomsheets.statistics.tableview

data class Cell(
    val value: String,
)

data class ColumnHeader(
    val value: String,
)

data class RowHeader(
    val value: String,
)

