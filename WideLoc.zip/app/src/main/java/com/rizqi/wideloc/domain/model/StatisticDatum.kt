package com.rizqi.wideloc.domain.model

data class StatisticDatum(
    val timestamp: Long,
    val value: Double,
)
