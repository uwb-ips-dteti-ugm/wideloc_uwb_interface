package com.rizqi.wideloc.data.repository

class AppRepositoryImpl {
}