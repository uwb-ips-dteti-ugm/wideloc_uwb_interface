package com.rizqi.wideloc.domain.model

data class TWRData(
    val address1: Int,
    val address2: Int,
    val timestamp: Int,
    val distance: Double
)
