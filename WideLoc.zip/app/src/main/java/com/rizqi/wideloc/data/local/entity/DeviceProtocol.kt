package com.rizqi.wideloc.data.local.entity

enum class DeviceProtocol {
    WiFi,
    Bluetooth
}