package com.rizqi.wideloc.domain.model

enum class MapUnit {
    MM,
    CM,
    M
}