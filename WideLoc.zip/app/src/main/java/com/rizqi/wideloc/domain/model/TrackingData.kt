package com.rizqi.wideloc.domain.model

data class TrackingData(
    val x: Double,
    val y: Double,
    val z: Double,
)
