package com.rizqi.wideloc.domain.model

data class WifiConfigData(
    val port: Int,
    val mdns: String
)
