package com.rizqi.wideloc.data.local.entity

data class DeviceOffsetEntity(
    val x: Double,
    val y: Double,
    val z: Double,
)
