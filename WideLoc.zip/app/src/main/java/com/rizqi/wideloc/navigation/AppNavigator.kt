package com.rizqi.wideloc.navigation

class AppNavigator {
}