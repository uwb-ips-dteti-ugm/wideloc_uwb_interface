package com.rizqi.wideloc.domain.model

data class DeviceOffsetData(
    val x: Double,
    val y: Double,
    val z: Double,
)
