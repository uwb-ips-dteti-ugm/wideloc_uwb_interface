package com.rizqi.wideloc.domain.model

data class LatencyData(
    val timestamp: Long,
    val latency: Double,
)