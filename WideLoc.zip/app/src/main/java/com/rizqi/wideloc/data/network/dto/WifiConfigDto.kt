package com.rizqi.wideloc.data.network.dto

data class WifiConfigDto(
    val port: Int,
    val mdns: String
)
