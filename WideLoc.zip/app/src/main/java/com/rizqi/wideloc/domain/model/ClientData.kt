package com.rizqi.wideloc.domain.model

data class ClientData(
    val address: Int,
    val mode: Int,
    val lastUpdate: Int
)
