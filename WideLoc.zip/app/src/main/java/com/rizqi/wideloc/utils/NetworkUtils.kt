package com.rizqi.wideloc.utils

class NetworkUtils {
}