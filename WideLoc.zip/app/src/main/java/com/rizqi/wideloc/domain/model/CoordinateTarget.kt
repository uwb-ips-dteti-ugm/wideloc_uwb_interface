package com.rizqi.wideloc.domain.model

enum class CoordinateTarget {
    SERVER,
    ANCHOR,
    CLIENT,
    MAP
}