package com.rizqi.wideloc.data.network.dto

data class SuccessDto(
    val status: String,
)
