package com.rizqi.wideloc.di

class AppModule {
}